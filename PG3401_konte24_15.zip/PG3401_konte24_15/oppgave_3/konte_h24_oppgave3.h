#ifndef konte_h24_oppgave3
#define konte_h24_oppgave3

int ftp_check_user(char *pszUsername, char *pszPassword);

#endif 
